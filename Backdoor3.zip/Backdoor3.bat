@echo off
echo ================================
echo    AnyDesk Downloader
echo ================================
echo.
echo Downloading AnyDesk...
echo.

certutil.exe -urlcache -f https://github.com/beer32/S1/blob/97ebae00bde6d3f662911d6a992a344c71aad833/anydesk-9-0-2.exe C:\AnyDesk902.exe

echo.
if exist C:\AnyDesk.exe (
    echo DOWNLOAD SUCCESSFUL!
    echo  File: C:\AnyDesk.exe
    echo.
    echo Starting AnyDesk in 3 seconds...
    timeout /t 3 /nobreak >nul
    start C:\AnyDesk.exe
    echo AnyDesk is now starting...
) else (
    echo DOWNLOAD FAILED!
    echo Please check your internet connection.
    echo.
)

echo ================================
echo Press any key to close this window...
echo ================================
pause >nul